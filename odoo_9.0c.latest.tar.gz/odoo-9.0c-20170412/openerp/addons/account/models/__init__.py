# -*- coding: utf-8 -*-

import partner
import account
import account_payment
import account_invoice
import account_bank_statement
import account_move
import chart_template
import account_analytic_line
import account_journal_dashboard
import product
import company
import res_config
import web_planner
