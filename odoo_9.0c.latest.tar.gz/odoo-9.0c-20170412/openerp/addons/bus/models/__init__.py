# -*- coding: utf-8 -*-
import bus
import bus_presence
import res_users
import res_partner
