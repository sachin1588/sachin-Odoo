{
"name" : "Sales order Inherit",
"version" : "1.1",
"author" : "EvonTech",
"category" : "Generic Modules/Sales",
"website" : "http://www.evontech.com",
"description": "Module to inherit sales order view.",
"depends" : ["sale"],
"init_xml" : [],
"update_xml" : ["sale_order_form_inherit_view.xml"],
"active": False,
"installable": True
}